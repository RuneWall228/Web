from django.urls import path
from . import views
urlpatterns = [
    path('', views.RecipesHome.as_view(), name='recipes'),
    path('create_recipes', views.Create.as_view(), name='create_recipes'),
    path('<slug:recipes_slug>/', views.ShowRecipes.as_view(), name='recipes-detail'),
    path('diet/<slug:diet_slug>/', views.RecipesDiet.as_view(), name='diets'),
]