from django import template
from ..models import *

register = template.Library()

@register.simple_tag(name = 'getdiets')
def get_diets(filter=None):
    if not filter:
        return Diet.objects.all()
    else:
        return Diet.objects.filter(pk=filter)

@register.inclusion_tag('recipes/list_diets.html')
def show_diet(sort=None, diet_selected=0):
    if not sort:
        diets_cat = Diet.objects.all()
    else:
        diets_cat = Diet.objects.order_by(sort)
    return {'diets_cat':diets_cat, 'diet_selected':diet_selected}