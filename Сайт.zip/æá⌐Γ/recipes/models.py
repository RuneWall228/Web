from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse
from django.utils.text import slugify
from transliterate import translit


class NewRecipe(models.Model):
    title = models.CharField('Название рецепта', max_length=70)
    slug = models.SlugField(max_length=70, unique=True, db_index=True, blank=True)
    description = models.TextField('Описание рецепта')
    preparation = models.TextField('Рецепт')
    tags = models.CharField('Теги', max_length=70) # какая диета, мб типо хештеги(без сахара и т.п.)
    photos = models.ImageField(upload_to='images/%Y-%m-%d/', verbose_name='Фото')
    time_create = models.DateTimeField(auto_now_add=True, verbose_name='Время создания')
    is_published = models.BooleanField(default=False, verbose_name='Публикация')
    diet = models.ForeignKey('Diet', on_delete=models.PROTECT, null=False, verbose_name='Диеты')

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            # Преобразование русских букв в английские
            translit_title = translit(self.title, 'ru', reversed=True)
            # Создание slug из преобразованного названия
            base_slug = slugify(translit_title)
            # Проверка наличия слага
            slug = base_slug
            counter = 1
            while NewRecipe.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('recipes-detail', kwargs={'recipes_slug': self.slug})

    class Meta:
        verbose_name = 'Рецепты'
        verbose_name_plural = 'Рецепты'
        ordering = ['-time_create','title']

class Diet(models.Model):
    name = models.CharField(max_length=70, db_index=True, verbose_name='Диета №')
    slug = models.SlugField(max_length=70, unique=True, db_index=True, verbose_name='URL')

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('diets', kwargs={'diet_slug': self.slug})

    class Meta:
        verbose_name = 'Диеты'
        verbose_name_plural = 'Диеты'
        ordering = ['name']