from django.db.models import Count

from .models import *


class DataMixin:
    paginate_by = 12

    def get_user_context(self, **kwargs):
        context = kwargs
        diets = Diet.objects.annotate(Count('newrecipe'))

        context['diets'] = diets
        if 'diet_selected' not in context:
            context['diet_selected'] = 0
        return context
