from .models import *
from django.forms import ModelForm,TextInput,Textarea,ModelChoiceField


class NewRecipeForm(ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['diet'].empty_label = "Диета не выбрана"



    class Meta:
        model = NewRecipe
        fields = ['title', 'description', 'preparation', 'tags', 'photos', 'diet']

        widgets = {
            'title': TextInput(attrs={
                'class':'form-control',
                'placeholder': 'Название рецепта',
            }),
            'description': Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Описание рецепта'
            }),
            'preparation': Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Рецепт'
            }),
            'tags': TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Теги'
            })
        }




