from django.http import HttpResponse, Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin

from .forms import *
from .models import *
from .utils import *



class RecipesHome(DataMixin, ListView):
    model = NewRecipe
    template_name = 'recipes/recipes.html'
    context_object_name = 'recipe'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['q'] = self.request.GET.get('q')
        c_def = self.get_user_context(title='Рецепты')

        return dict(list(context.items())+list(c_def.items()))

    def get_queryset(self):
        if self.request.GET.get('q') == None:
            return NewRecipe.objects.filter(is_published=True)
        else:
            return NewRecipe.objects.filter(title__iregex=self.request.GET.get('q'),is_published=True)



# def recipes(request):
#     recipe = NewRecipe.objects.all()
#
#     context = {
#         'recipe': recipe,
#         'diet_selected': 0,
#     }
#
#     return render(request, 'recipes/recipes.html', context=context)


class Create(LoginRequiredMixin, DataMixin, SuccessMessageMixin, CreateView):
    form_class = NewRecipeForm
    template_name = 'recipes/create_recipes.html'
    success_url = reverse_lazy('recipes')
    login_url = reverse_lazy('register')
    success_message = "Ваш рецепт успешно отправлен на проверку администратору. Пожалуйста, ожидайте подтверждения."

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title='Добавить рецепт')
        context['success_message'] = self.success_message
        return dict(list(context.items())+list(c_def.items()))

# def create(request):
#     if request.method == 'POST':
#         form = NewRecipeForm(request.POST, request.FILES)
#         if form.is_valid():
#             form.save()
#             return redirect('home')
#     else:
#         form = NewRecipeForm()
#     return render(request, 'recipes/create_recipes.html', {'form': form})

class ShowRecipes(DataMixin, DetailView):
    model = NewRecipe
    template_name = 'recipes/detail_view.html'
    slug_url_kwarg = 'recipes_slug'
    context_object_name = 'recipe'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = context['recipe']
        c_def = self.get_user_context(title=context['recipe'])
        return dict(list(context.items()) + list(c_def.items()))


# def recipes_detail(request, recipes_slug):
#     recipe = get_object_or_404(NewRecipe, slug=recipes_slug)
#
#     context = {
#         'recipe': recipe,
#         'diet_selected': recipe.diet_id,
#         'title': recipe.title,
#     }
#
#     return render(request, 'recipes/detail_view.html', context=context)

class RecipesDiet(DataMixin, ListView):
    model = NewRecipe
    template_name = 'recipes/recipes.html'
    context_object_name = 'recipe'
    allow_empty = False

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title=str(context['recipe'][0].diet),diet_selected=context['recipe'][0].diet_id)
        return dict(list(context.items()) + list(c_def.items()))

    def get_queryset(self):
        return NewRecipe.objects.filter(diet__slug=self.kwargs['diet_slug'], is_published=True)



# def show_diet(request, diet_id):
#     recipe = NewRecipe.objects.filter(diet_id=diet_id)
#
#     if len(recipe) == 0:  #ошибка 404 если нет рецептов
#         raise Http404()
#
#     context = {
#         'recipe': recipe,
#         'diet_selected': diet_id,
#     }
#
#     return render(request, 'recipes/recipes.html', context=context)
